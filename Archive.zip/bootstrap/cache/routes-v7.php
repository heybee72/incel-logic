<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/api/auth/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VLczuAPyeHUfBMhQ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Z3g48ovZBljHbb2p',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WtifFzYAh5D9Rlco',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yBiU0IOd6rpQEFKK',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GoqfxdDvnE7HCUlx',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/refresh' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3RuFGtK7CyWiNC0y',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/change-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zUnruRQLJrPd2RRl',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/forgot-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HxhwhSmPV4lXVhlO',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::W7m1rq2Ccr3XZAi2',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bNCPw3SqxIouPE27',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vJ41scXW6FaWjYO1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AoT6nNmiFZzBP9ct',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/refresh' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kbhbGr8aYEdfjLdx',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/agents/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iOOPOfLIaDsa2KLQ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/agents/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::R46UMmOXtR0BoTxS',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/agents/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mnMec86EHs3JbCSu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/agents/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qjjufIjeAsPBQwe8',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/agents/refresh' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6Jf85iynny9ztgTI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tour_bookings/userAdd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FUEd32WVAUjdq2Vu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tour_bookings/agentAdd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5lq33CyRGjsMqrLV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tour_bookings/agentViewBooking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i8nvDjsStsxTEjY0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tour_bookings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NHD0ExIHABA6uofa',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tour_bookings/viewBookingForUsers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wYIbXvkmqR7yXoh6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tour_bookings/viewBookingForAgents' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xpvKEzGVLM5vvhlW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/hotel_bookings/userAdd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XdtYyHZOgMB3J2fI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/hotel_bookings/agentAdd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DzM6NN9qnuyVQdKF',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/hotel_bookings/agentViewBooking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jOs6tkxohn2KdgYZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/hotel_bookings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EZbA8GxcfJE0ASlf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/hotel_bookings/viewBookingForUsers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::R6eXOcyNQHZzBv4s',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/hotel_bookings/viewBookingForAgents' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XcxwNFMHUrhDrvRL',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/flight_bookings/userAdd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UDSQLu1mAnPTewZY',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/flight_bookings/agentAdd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EXaHWtAJpswpCoDp',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/flight_bookings/agentViewBooking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::81MmmkGDWGTADFaB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/flight_bookings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::68KSZZNjkZJLhyyx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/flight_bookings/viewBookingForUsers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8h2ue7vMHat6Srhx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/flight_bookings/viewBookingForAgents' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::diTIGMThRXSbtrOq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/visa_applications/userAdd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8qRzIz908DmVveox',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/visa_applications/agentAdd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bFsprKD8aEv5akx9',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/visa_applications/agentViewBooking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5mllBIKw1NpYwNGi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/visa_applications' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2rqNyQBCKxlvbZRO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/visa_applications/viewBookingForUsers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::awMqj9fBDwF4xaie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/visa_applications/viewBookingForAgents' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hV208GaPjnQTaldc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/banners' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mP252pIs4dGuF2Vb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/banners/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hnNJ0vnMYT08RX7c',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/blogs' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::06wXFjoswaQtYJYK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/blogs/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0PaBkFpt7tbXKBUR',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/categories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4O2weUHREqaAfPOw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/categories/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fEVUyH31K7RJ8DJj',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/news' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MkdD3aH6qo3qdWWi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/news/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RG3mO1KkSX8cVQIN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/currency_types' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mR23clQWWt2USN9d',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/currency_types/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Nwd1PI7eqMeOVDnm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/markup_types' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xBDp3UCX83gmz9gv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/markup_types/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8lOfvNhqK2JrJT3r',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/markups' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jaokV2aAKriFXOTA',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/markups/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ip726Gy70iM9SYap',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/currencies' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xSSEBoBqgoS7tejS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/currencies/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RofaxAMK3Q1Hn0lU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/mark_ups' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RPsv9LV5Z01BqbVz',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/mark_ups/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rA47ZSg8KwyW7YQV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/contacts' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5SGsFcwmh4LoKTGy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/contacts/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6Epy86Aiflab8S9c',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/travellers/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dkzywoY1A302J1yL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/travellers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Dgaf7MAUPQMjPgTR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/travellers/agent_view' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8RNhzOaqzOVdOnLq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/vacations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZK5rAQtHJGK8cChM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/vacations/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3nRNdw380wxjDgJy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/visa_types' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xR6eng0yqnQsfu2U',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/visa_types/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SfecdmVlAVQcG7lk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/addons' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Q6jHrBeJRAPysGwR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/addons/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ahBrC3LXHcS1uyhh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bRbtbhsBE5Fwe7KM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/forgot_password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/(?|a(?|uth/delete/([^/]++)(*:38)|d(?|min/delete/([^/]++)(*:68)|dons/(?|view(?|/([^/]++)(*:99)|ByVacation/([^/]++)(*:125))|delete/([^/]++)(*:149)))|gents/delete/([^/]++)(*:180))|t(?|our_bookings/(?|view/([^/]++)(*:222)|delete/([^/]++)(*:245))|ravellers/(?|update/([^/]++)(*:282)|view/([^/]++)(*:303)|delete/([^/]++)(*:326)))|hotel_bookings/(?|view/([^/]++)(*:367)|delete/([^/]++)(*:390))|flight_bookings/(?|view/([^/]++)(*:431)|delete/([^/]++)(*:454))|v(?|isa_(?|applications/(?|view/([^/]++)(*:503)|delete/([^/]++)(*:526))|types/(?|view/([^/]++)(*:557)|delete/([^/]++)(*:580)))|acations/(?|view/([^/]++)(*:615)|delete/([^/]++)(*:638)))|b(?|anners/(?|view/([^/]++)(*:675)|delete/([^/]++)(*:698))|logs/(?|view/([^/]++)(*:728)|update/([^/]++)(*:751)|delete/([^/]++)(*:774)))|c(?|ategories/(?|view/([^/]++)(*:814)|update/([^/]++)(*:837)|delete/([^/]++)(*:860))|urrenc(?|y_types/view/([^/]++)(*:899)|ies/view/([^/]++)(*:924))|ontacts/(?|view/([^/]++)(*:957)|delete/([^/]++)(*:980)))|news/(?|view/([^/]++)(*:1011)|update/([^/]++)(*:1035)|delete/([^/]++)(*:1059))|mark(?|up(?|_types/view/([^/]++)(*:1101)|s/(?|view(?|/([^/]++)(*:1131)|_selected_(?|agent_value/([^/]++)(*:1173)|customer_value/([^/]++)(*:1205)))|update_(?|agent/([^/]++)(*:1240)|customer/([^/]++)(*:1266))))|_ups/view/([^/]++)(*:1296))))/?$}sDu',
    ),
    3 => 
    array (
      38 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qtVS7RpLghhGH5mc',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      68 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ix6WeVjH2ZPwu7P2',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      99 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xeOp7LMA4vwo2a5O',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      125 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6BME6369S6lIhnuK',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      149 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UnRZZWMWQnmIo7tF',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      180 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oJADiFj8cyg7YJPF',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      222 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RlS4vnQhqrPJN2FU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      245 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::26ffQHZuBQLT1iC8',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      282 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6chmF19DJL3jshqR',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      303 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hAMywvFxwu16nGv5',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      326 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YFeTJWHOtrMAOetS',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      367 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3d4R4ynipKZUsuOu',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      390 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::acpgnlt1GEsnxyyR',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      431 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::W6l3XzXn2SIoPKQg',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      454 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AKoO0SqQuri4xbLk',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      503 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ESyOfd2vrfiHCqse',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      526 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UdUwmx67uOj9qBnZ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      557 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ceWVIjhAOeLB9tmo',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      580 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::27F1Sez5HXQkXrv2',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      615 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZAqr0L4lQOtY9D9B',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      638 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7NMfyDftDvIgGuzD',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      675 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Hr7yNUD1DSNDGxHF',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      698 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HlLr8329gQHih622',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      728 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aR2ngAVIqHli9DFB',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      751 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3q70HCX2YKN9psqm',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      774 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::u95U3j4OqvaAK4is',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      814 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ls2y2N4GzfcOQMSz',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      837 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5nPvjx6L06zpE7iO',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      860 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6xdngHBAN972ZcEp',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      899 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wfQuTdB5FNNNOQ2Z',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      924 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PqVzxjENrgRPrda4',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      957 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QtNp9SAnaz5zDC5l',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      980 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H19WIhuE2PRm1yne',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1011 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1gdUUXh0wYfg3ljA',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1035 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BRF3bFeVfh3KL3qu',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1059 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::07QTCgNNQZYPyk3V',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1101 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pJTJXSjbkXeBy8lq',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1131 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vbb4MvQDFoVuHf3i',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1173 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cZaF67n2wJsYsAH3',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1205 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5jB0eFnYqBh5J1PA',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1240 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lRVJOyMvg3DlAiZ2',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1266 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4BYuWVuc2pTZ7fQy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1296 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6J8TW40qSobHNz5b',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::VLczuAPyeHUfBMhQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/auth/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\AuthController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::VLczuAPyeHUfBMhQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Z3g48ovZBljHbb2p' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/auth/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@register',
        'controller' => 'App\\Http\\Controllers\\AuthController@register',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::Z3g48ovZBljHbb2p',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::WtifFzYAh5D9Rlco' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/auth/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@profile',
        'controller' => 'App\\Http\\Controllers\\AuthController@profile',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::WtifFzYAh5D9Rlco',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yBiU0IOd6rpQEFKK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/auth/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@update',
        'controller' => 'App\\Http\\Controllers\\AuthController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::yBiU0IOd6rpQEFKK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::GoqfxdDvnE7HCUlx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/auth/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\AuthController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::GoqfxdDvnE7HCUlx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3RuFGtK7CyWiNC0y' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/auth/refresh',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@refresh',
        'controller' => 'App\\Http\\Controllers\\AuthController@refresh',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::3RuFGtK7CyWiNC0y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qtVS7RpLghhGH5mc' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/auth/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@delete',
        'controller' => 'App\\Http\\Controllers\\AuthController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::qtVS7RpLghhGH5mc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zUnruRQLJrPd2RRl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/auth/change-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@change_password',
        'controller' => 'App\\Http\\Controllers\\AuthController@change_password',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::zUnruRQLJrPd2RRl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::HxhwhSmPV4lXVhlO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/auth/forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ForgotPasswordController@forgot',
        'controller' => 'App\\Http\\Controllers\\ForgotPasswordController@forgot',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::HxhwhSmPV4lXVhlO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::W7m1rq2Ccr3XZAi2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminAuthController@login',
        'controller' => 'App\\Http\\Controllers\\AdminAuthController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::W7m1rq2Ccr3XZAi2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bNCPw3SqxIouPE27' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminAuthController@register',
        'controller' => 'App\\Http\\Controllers\\AdminAuthController@register',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::bNCPw3SqxIouPE27',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::vJ41scXW6FaWjYO1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminAuthController@profile',
        'controller' => 'App\\Http\\Controllers\\AdminAuthController@profile',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::vJ41scXW6FaWjYO1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::AoT6nNmiFZzBP9ct' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminAuthController@logout',
        'controller' => 'App\\Http\\Controllers\\AdminAuthController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::AoT6nNmiFZzBP9ct',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::kbhbGr8aYEdfjLdx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/refresh',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminAuthController@refresh',
        'controller' => 'App\\Http\\Controllers\\AdminAuthController@refresh',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::kbhbGr8aYEdfjLdx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ix6WeVjH2ZPwu7P2' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminAuthController@delete',
        'controller' => 'App\\Http\\Controllers\\AdminAuthController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::ix6WeVjH2ZPwu7P2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::iOOPOfLIaDsa2KLQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/agents/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AgentAuthController@login',
        'controller' => 'App\\Http\\Controllers\\AgentAuthController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/agents',
        'where' => 
        array (
        ),
        'as' => 'generated::iOOPOfLIaDsa2KLQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::R46UMmOXtR0BoTxS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/agents/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AgentAuthController@register',
        'controller' => 'App\\Http\\Controllers\\AgentAuthController@register',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/agents',
        'where' => 
        array (
        ),
        'as' => 'generated::R46UMmOXtR0BoTxS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mnMec86EHs3JbCSu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/agents/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AgentAuthController@profile',
        'controller' => 'App\\Http\\Controllers\\AgentAuthController@profile',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/agents',
        'where' => 
        array (
        ),
        'as' => 'generated::mnMec86EHs3JbCSu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qjjufIjeAsPBQwe8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/agents/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AgentAuthController@logout',
        'controller' => 'App\\Http\\Controllers\\AgentAuthController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/agents',
        'where' => 
        array (
        ),
        'as' => 'generated::qjjufIjeAsPBQwe8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6Jf85iynny9ztgTI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/agents/refresh',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AgentAuthController@refresh',
        'controller' => 'App\\Http\\Controllers\\AgentAuthController@refresh',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/agents',
        'where' => 
        array (
        ),
        'as' => 'generated::6Jf85iynny9ztgTI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oJADiFj8cyg7YJPF' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/agents/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\AgentAuthController@delete',
        'controller' => 'App\\Http\\Controllers\\AgentAuthController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/agents',
        'where' => 
        array (
        ),
        'as' => 'generated::oJADiFj8cyg7YJPF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FUEd32WVAUjdq2Vu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tour_bookings/userAdd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\TourBookingController@userAdd',
        'controller' => 'App\\Http\\Controllers\\TourBookingController@userAdd',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/tour_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::FUEd32WVAUjdq2Vu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5lq33CyRGjsMqrLV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tour_bookings/agentAdd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verifyAgent',
        ),
        'uses' => 'App\\Http\\Controllers\\TourBookingController@agentAdd',
        'controller' => 'App\\Http\\Controllers\\TourBookingController@agentAdd',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/tour_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::5lq33CyRGjsMqrLV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::i8nvDjsStsxTEjY0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tour_bookings/agentViewBooking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verifyAgent',
        ),
        'uses' => 'App\\Http\\Controllers\\TourBookingController@agentView',
        'controller' => 'App\\Http\\Controllers\\TourBookingController@agentView',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/tour_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::i8nvDjsStsxTEjY0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::NHD0ExIHABA6uofa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tour_bookings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\TourBookingController@index',
        'controller' => 'App\\Http\\Controllers\\TourBookingController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/tour_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::NHD0ExIHABA6uofa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RlS4vnQhqrPJN2FU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tour_bookings/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\TourBookingController@view',
        'controller' => 'App\\Http\\Controllers\\TourBookingController@view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/tour_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::RlS4vnQhqrPJN2FU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wYIbXvkmqR7yXoh6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tour_bookings/viewBookingForUsers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\TourBookingController@userBookings',
        'controller' => 'App\\Http\\Controllers\\TourBookingController@userBookings',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/tour_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::wYIbXvkmqR7yXoh6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xpvKEzGVLM5vvhlW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tour_bookings/viewBookingForAgents',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\TourBookingController@agentBookings',
        'controller' => 'App\\Http\\Controllers\\TourBookingController@agentBookings',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/tour_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::xpvKEzGVLM5vvhlW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::26ffQHZuBQLT1iC8' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/tour_bookings/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\TourBookingController@delete',
        'controller' => 'App\\Http\\Controllers\\TourBookingController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/tour_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::26ffQHZuBQLT1iC8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XdtYyHZOgMB3J2fI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/hotel_bookings/userAdd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\HotelBookingController@userAdd',
        'controller' => 'App\\Http\\Controllers\\HotelBookingController@userAdd',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/hotel_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::XdtYyHZOgMB3J2fI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::DzM6NN9qnuyVQdKF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/hotel_bookings/agentAdd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verifyAgent',
        ),
        'uses' => 'App\\Http\\Controllers\\HotelBookingController@agentAdd',
        'controller' => 'App\\Http\\Controllers\\HotelBookingController@agentAdd',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/hotel_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::DzM6NN9qnuyVQdKF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jOs6tkxohn2KdgYZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/hotel_bookings/agentViewBooking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verifyAgent',
        ),
        'uses' => 'App\\Http\\Controllers\\HotelBookingController@agentView',
        'controller' => 'App\\Http\\Controllers\\HotelBookingController@agentView',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/hotel_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::jOs6tkxohn2KdgYZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::EZbA8GxcfJE0ASlf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/hotel_bookings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\HotelBookingController@index',
        'controller' => 'App\\Http\\Controllers\\HotelBookingController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/hotel_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::EZbA8GxcfJE0ASlf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3d4R4ynipKZUsuOu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/hotel_bookings/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\HotelBookingController@view',
        'controller' => 'App\\Http\\Controllers\\HotelBookingController@view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/hotel_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::3d4R4ynipKZUsuOu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::R6eXOcyNQHZzBv4s' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/hotel_bookings/viewBookingForUsers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\HotelBookingController@userBookings',
        'controller' => 'App\\Http\\Controllers\\HotelBookingController@userBookings',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/hotel_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::R6eXOcyNQHZzBv4s',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XcxwNFMHUrhDrvRL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/hotel_bookings/viewBookingForAgents',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\HotelBookingController@agentBookings',
        'controller' => 'App\\Http\\Controllers\\HotelBookingController@agentBookings',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/hotel_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::XcxwNFMHUrhDrvRL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::acpgnlt1GEsnxyyR' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/hotel_bookings/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\HotelBookingController@delete',
        'controller' => 'App\\Http\\Controllers\\HotelBookingController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/hotel_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::acpgnlt1GEsnxyyR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::UDSQLu1mAnPTewZY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/flight_bookings/userAdd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\FlightController@userAdd',
        'controller' => 'App\\Http\\Controllers\\FlightController@userAdd',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/flight_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::UDSQLu1mAnPTewZY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::EXaHWtAJpswpCoDp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/flight_bookings/agentAdd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verifyAgent',
        ),
        'uses' => 'App\\Http\\Controllers\\FlightController@agentAdd',
        'controller' => 'App\\Http\\Controllers\\FlightController@agentAdd',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/flight_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::EXaHWtAJpswpCoDp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::81MmmkGDWGTADFaB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/flight_bookings/agentViewBooking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verifyAgent',
        ),
        'uses' => 'App\\Http\\Controllers\\FlightController@agentView',
        'controller' => 'App\\Http\\Controllers\\FlightController@agentView',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/flight_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::81MmmkGDWGTADFaB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::68KSZZNjkZJLhyyx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/flight_bookings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\FlightController@index',
        'controller' => 'App\\Http\\Controllers\\FlightController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/flight_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::68KSZZNjkZJLhyyx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::W6l3XzXn2SIoPKQg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/flight_bookings/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\FlightController@view',
        'controller' => 'App\\Http\\Controllers\\FlightController@view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/flight_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::W6l3XzXn2SIoPKQg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8h2ue7vMHat6Srhx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/flight_bookings/viewBookingForUsers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\FlightController@userBookings',
        'controller' => 'App\\Http\\Controllers\\FlightController@userBookings',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/flight_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::8h2ue7vMHat6Srhx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::diTIGMThRXSbtrOq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/flight_bookings/viewBookingForAgents',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\FlightController@agentBookings',
        'controller' => 'App\\Http\\Controllers\\FlightController@agentBookings',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/flight_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::diTIGMThRXSbtrOq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::AKoO0SqQuri4xbLk' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/flight_bookings/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\FlightController@delete',
        'controller' => 'App\\Http\\Controllers\\FlightController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/flight_bookings',
        'where' => 
        array (
        ),
        'as' => 'generated::AKoO0SqQuri4xbLk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8qRzIz908DmVveox' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/visa_applications/userAdd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\VisaApplicationController@userAdd',
        'controller' => 'App\\Http\\Controllers\\VisaApplicationController@userAdd',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/visa_applications',
        'where' => 
        array (
        ),
        'as' => 'generated::8qRzIz908DmVveox',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bFsprKD8aEv5akx9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/visa_applications/agentAdd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verifyAgent',
        ),
        'uses' => 'App\\Http\\Controllers\\VisaApplicationController@agentAdd',
        'controller' => 'App\\Http\\Controllers\\VisaApplicationController@agentAdd',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/visa_applications',
        'where' => 
        array (
        ),
        'as' => 'generated::bFsprKD8aEv5akx9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5mllBIKw1NpYwNGi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/visa_applications/agentViewBooking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verifyAgent',
        ),
        'uses' => 'App\\Http\\Controllers\\VisaApplicationController@agentView',
        'controller' => 'App\\Http\\Controllers\\VisaApplicationController@agentView',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/visa_applications',
        'where' => 
        array (
        ),
        'as' => 'generated::5mllBIKw1NpYwNGi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2rqNyQBCKxlvbZRO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/visa_applications',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\VisaApplicationController@index',
        'controller' => 'App\\Http\\Controllers\\VisaApplicationController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/visa_applications',
        'where' => 
        array (
        ),
        'as' => 'generated::2rqNyQBCKxlvbZRO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ESyOfd2vrfiHCqse' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/visa_applications/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\VisaApplicationController@view',
        'controller' => 'App\\Http\\Controllers\\VisaApplicationController@view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/visa_applications',
        'where' => 
        array (
        ),
        'as' => 'generated::ESyOfd2vrfiHCqse',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::awMqj9fBDwF4xaie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/visa_applications/viewBookingForUsers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\VisaApplicationController@userBookings',
        'controller' => 'App\\Http\\Controllers\\VisaApplicationController@userBookings',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/visa_applications',
        'where' => 
        array (
        ),
        'as' => 'generated::awMqj9fBDwF4xaie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hV208GaPjnQTaldc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/visa_applications/viewBookingForAgents',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\VisaApplicationController@agentBookings',
        'controller' => 'App\\Http\\Controllers\\VisaApplicationController@agentBookings',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/visa_applications',
        'where' => 
        array (
        ),
        'as' => 'generated::hV208GaPjnQTaldc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::UdUwmx67uOj9qBnZ' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/visa_applications/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\VisaApplicationController@delete',
        'controller' => 'App\\Http\\Controllers\\VisaApplicationController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/visa_applications',
        'where' => 
        array (
        ),
        'as' => 'generated::UdUwmx67uOj9qBnZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mP252pIs4dGuF2Vb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/banners',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\BannerController@index',
        'controller' => 'App\\Http\\Controllers\\BannerController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/banners',
        'where' => 
        array (
        ),
        'as' => 'generated::mP252pIs4dGuF2Vb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Hr7yNUD1DSNDGxHF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/banners/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\BannerController@view',
        'controller' => 'App\\Http\\Controllers\\BannerController@view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/banners',
        'where' => 
        array (
        ),
        'as' => 'generated::Hr7yNUD1DSNDGxHF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hnNJ0vnMYT08RX7c' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/banners/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\BannerController@add',
        'controller' => 'App\\Http\\Controllers\\BannerController@add',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/banners',
        'where' => 
        array (
        ),
        'as' => 'generated::hnNJ0vnMYT08RX7c',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::HlLr8329gQHih622' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/banners/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\BannerController@delete',
        'controller' => 'App\\Http\\Controllers\\BannerController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/banners',
        'where' => 
        array (
        ),
        'as' => 'generated::HlLr8329gQHih622',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::06wXFjoswaQtYJYK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/blogs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\BlogController@index',
        'controller' => 'App\\Http\\Controllers\\BlogController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/blogs',
        'where' => 
        array (
        ),
        'as' => 'generated::06wXFjoswaQtYJYK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::aR2ngAVIqHli9DFB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/blogs/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\BlogController@view',
        'controller' => 'App\\Http\\Controllers\\BlogController@view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/blogs',
        'where' => 
        array (
        ),
        'as' => 'generated::aR2ngAVIqHli9DFB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3q70HCX2YKN9psqm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/blogs/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\BlogController@update',
        'controller' => 'App\\Http\\Controllers\\BlogController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/blogs',
        'where' => 
        array (
        ),
        'as' => 'generated::3q70HCX2YKN9psqm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::0PaBkFpt7tbXKBUR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/blogs/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\BlogController@add',
        'controller' => 'App\\Http\\Controllers\\BlogController@add',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/blogs',
        'where' => 
        array (
        ),
        'as' => 'generated::0PaBkFpt7tbXKBUR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::u95U3j4OqvaAK4is' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/blogs/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\BlogController@delete',
        'controller' => 'App\\Http\\Controllers\\BlogController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/blogs',
        'where' => 
        array (
        ),
        'as' => 'generated::u95U3j4OqvaAK4is',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::4O2weUHREqaAfPOw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@index',
        'controller' => 'App\\Http\\Controllers\\CategoryController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/categories',
        'where' => 
        array (
        ),
        'as' => 'generated::4O2weUHREqaAfPOw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Ls2y2N4GzfcOQMSz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/categories/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@view',
        'controller' => 'App\\Http\\Controllers\\CategoryController@view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/categories',
        'where' => 
        array (
        ),
        'as' => 'generated::Ls2y2N4GzfcOQMSz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5nPvjx6L06zpE7iO' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/categories/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@update',
        'controller' => 'App\\Http\\Controllers\\CategoryController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/categories',
        'where' => 
        array (
        ),
        'as' => 'generated::5nPvjx6L06zpE7iO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::fEVUyH31K7RJ8DJj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/categories/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@add',
        'controller' => 'App\\Http\\Controllers\\CategoryController@add',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/categories',
        'where' => 
        array (
        ),
        'as' => 'generated::fEVUyH31K7RJ8DJj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6xdngHBAN972ZcEp' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/categories/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@delete',
        'controller' => 'App\\Http\\Controllers\\CategoryController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/categories',
        'where' => 
        array (
        ),
        'as' => 'generated::6xdngHBAN972ZcEp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::MkdD3aH6qo3qdWWi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/news',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\NewsController@index',
        'controller' => 'App\\Http\\Controllers\\NewsController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/news',
        'where' => 
        array (
        ),
        'as' => 'generated::MkdD3aH6qo3qdWWi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::1gdUUXh0wYfg3ljA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/news/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\NewsController@view',
        'controller' => 'App\\Http\\Controllers\\NewsController@view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/news',
        'where' => 
        array (
        ),
        'as' => 'generated::1gdUUXh0wYfg3ljA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::BRF3bFeVfh3KL3qu' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/news/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\NewsController@update',
        'controller' => 'App\\Http\\Controllers\\NewsController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/news',
        'where' => 
        array (
        ),
        'as' => 'generated::BRF3bFeVfh3KL3qu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RG3mO1KkSX8cVQIN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/news/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\NewsController@add',
        'controller' => 'App\\Http\\Controllers\\NewsController@add',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/news',
        'where' => 
        array (
        ),
        'as' => 'generated::RG3mO1KkSX8cVQIN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::07QTCgNNQZYPyk3V' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/news/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\NewsController@delete',
        'controller' => 'App\\Http\\Controllers\\NewsController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/news',
        'where' => 
        array (
        ),
        'as' => 'generated::07QTCgNNQZYPyk3V',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mR23clQWWt2USN9d' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/currency_types',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\CurrencyTypeController@index',
        'controller' => 'App\\Http\\Controllers\\CurrencyTypeController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/currency_types',
        'where' => 
        array (
        ),
        'as' => 'generated::mR23clQWWt2USN9d',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wfQuTdB5FNNNOQ2Z' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/currency_types/view/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\CurrencyTypeController@view',
        'controller' => 'App\\Http\\Controllers\\CurrencyTypeController@view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/currency_types',
        'where' => 
        array (
        ),
        'as' => 'generated::wfQuTdB5FNNNOQ2Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Nwd1PI7eqMeOVDnm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/currency_types/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CurrencyTypeController@add',
        'controller' => 'App\\Http\\Controllers\\CurrencyTypeController@add',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/currency_types',
        'where' => 
        array (
        ),
        'as' => 'generated::Nwd1PI7eqMeOVDnm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xBDp3UCX83gmz9gv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/markup_types',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\MarkUpTypeController@index',
        'controller' => 'App\\Http\\Controllers\\MarkUpTypeController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/markup_types',
        'where' => 
        array (
        ),
        'as' => 'generated::xBDp3UCX83gmz9gv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::pJTJXSjbkXeBy8lq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/markup_types/view/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\MarkUpTypeController@view',
        'controller' => 'App\\Http\\Controllers\\MarkUpTypeController@view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/markup_types',
        'where' => 
        array (
        ),
        'as' => 'generated::pJTJXSjbkXeBy8lq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8lOfvNhqK2JrJT3r' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/markup_types/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\MarkUpTypeController@add',
        'controller' => 'App\\Http\\Controllers\\MarkUpTypeController@add',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/markup_types',
        'where' => 
        array (
        ),
        'as' => 'generated::8lOfvNhqK2JrJT3r',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jaokV2aAKriFXOTA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/markups',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\MarkUpController@index',
        'controller' => 'App\\Http\\Controllers\\MarkUpController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/markups',
        'where' => 
        array (
        ),
        'as' => 'generated::jaokV2aAKriFXOTA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::vbb4MvQDFoVuHf3i' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/markups/view/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\MarkUpController@view',
        'controller' => 'App\\Http\\Controllers\\MarkUpController@view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/markups',
        'where' => 
        array (
        ),
        'as' => 'generated::vbb4MvQDFoVuHf3i',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::cZaF67n2wJsYsAH3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/markups/view_selected_agent_value/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\MarkUpController@view_selected_agent_value',
        'controller' => 'App\\Http\\Controllers\\MarkUpController@view_selected_agent_value',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/markups',
        'where' => 
        array (
        ),
        'as' => 'generated::cZaF67n2wJsYsAH3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5jB0eFnYqBh5J1PA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/markups/view_selected_customer_value/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\MarkUpController@view_selected_customer_value',
        'controller' => 'App\\Http\\Controllers\\MarkUpController@view_selected_customer_value',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/markups',
        'where' => 
        array (
        ),
        'as' => 'generated::5jB0eFnYqBh5J1PA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Ip726Gy70iM9SYap' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/markups/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\MarkUpController@add',
        'controller' => 'App\\Http\\Controllers\\MarkUpController@add',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/markups',
        'where' => 
        array (
        ),
        'as' => 'generated::Ip726Gy70iM9SYap',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lRVJOyMvg3DlAiZ2' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/markups/update_agent/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\MarkUpController@update_agent',
        'controller' => 'App\\Http\\Controllers\\MarkUpController@update_agent',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/markups',
        'where' => 
        array (
        ),
        'as' => 'generated::lRVJOyMvg3DlAiZ2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::4BYuWVuc2pTZ7fQy' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/markups/update_customer/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\MarkUpController@update_customer',
        'controller' => 'App\\Http\\Controllers\\MarkUpController@update_customer',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/markups',
        'where' => 
        array (
        ),
        'as' => 'generated::4BYuWVuc2pTZ7fQy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xSSEBoBqgoS7tejS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/currencies',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CurrencyController@index',
        'controller' => 'App\\Http\\Controllers\\CurrencyController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/currencies',
        'where' => 
        array (
        ),
        'as' => 'generated::xSSEBoBqgoS7tejS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::PqVzxjENrgRPrda4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/currencies/view/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\CurrencyController@view',
        'controller' => 'App\\Http\\Controllers\\CurrencyController@view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/currencies',
        'where' => 
        array (
        ),
        'as' => 'generated::PqVzxjENrgRPrda4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RofaxAMK3Q1Hn0lU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/currencies/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CurrencyController@add',
        'controller' => 'App\\Http\\Controllers\\CurrencyController@add',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/currencies',
        'where' => 
        array (
        ),
        'as' => 'generated::RofaxAMK3Q1Hn0lU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RPsv9LV5Z01BqbVz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/mark_ups',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CurrencyController@index',
        'controller' => 'App\\Http\\Controllers\\CurrencyController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/mark_ups',
        'where' => 
        array (
        ),
        'as' => 'generated::RPsv9LV5Z01BqbVz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6J8TW40qSobHNz5b' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/mark_ups/view/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\CurrencyController@view',
        'controller' => 'App\\Http\\Controllers\\CurrencyController@view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/mark_ups',
        'where' => 
        array (
        ),
        'as' => 'generated::6J8TW40qSobHNz5b',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rA47ZSg8KwyW7YQV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/mark_ups/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CurrencyController@add',
        'controller' => 'App\\Http\\Controllers\\CurrencyController@add',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/mark_ups',
        'where' => 
        array (
        ),
        'as' => 'generated::rA47ZSg8KwyW7YQV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5SGsFcwmh4LoKTGy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/contacts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\ContactController@index',
        'controller' => 'App\\Http\\Controllers\\ContactController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/contacts',
        'where' => 
        array (
        ),
        'as' => 'generated::5SGsFcwmh4LoKTGy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::QtNp9SAnaz5zDC5l' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/contacts/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\ContactController@view',
        'controller' => 'App\\Http\\Controllers\\ContactController@view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/contacts',
        'where' => 
        array (
        ),
        'as' => 'generated::QtNp9SAnaz5zDC5l',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6Epy86Aiflab8S9c' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/contacts/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ContactController@add',
        'controller' => 'App\\Http\\Controllers\\ContactController@add',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/contacts',
        'where' => 
        array (
        ),
        'as' => 'generated::6Epy86Aiflab8S9c',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::H19WIhuE2PRm1yne' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/contacts/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\ContactController@delete',
        'controller' => 'App\\Http\\Controllers\\ContactController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/contacts',
        'where' => 
        array (
        ),
        'as' => 'generated::H19WIhuE2PRm1yne',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::dkzywoY1A302J1yL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/travellers/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verifyAgent',
        ),
        'uses' => 'App\\Http\\Controllers\\TravellerController@add',
        'controller' => 'App\\Http\\Controllers\\TravellerController@add',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/travellers',
        'where' => 
        array (
        ),
        'as' => 'generated::dkzywoY1A302J1yL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6chmF19DJL3jshqR' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/travellers/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verifyAgent',
        ),
        'uses' => 'App\\Http\\Controllers\\TravellerController@update',
        'controller' => 'App\\Http\\Controllers\\TravellerController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/travellers',
        'where' => 
        array (
        ),
        'as' => 'generated::6chmF19DJL3jshqR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Dgaf7MAUPQMjPgTR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/travellers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\TravellerController@index',
        'controller' => 'App\\Http\\Controllers\\TravellerController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/travellers',
        'where' => 
        array (
        ),
        'as' => 'generated::Dgaf7MAUPQMjPgTR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hAMywvFxwu16nGv5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/travellers/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\TravellerController@view',
        'controller' => 'App\\Http\\Controllers\\TravellerController@view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/travellers',
        'where' => 
        array (
        ),
        'as' => 'generated::hAMywvFxwu16nGv5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8RNhzOaqzOVdOnLq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/travellers/agent_view',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verifyAgent',
        ),
        'uses' => 'App\\Http\\Controllers\\TravellerController@agent_view',
        'controller' => 'App\\Http\\Controllers\\TravellerController@agent_view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/travellers',
        'where' => 
        array (
        ),
        'as' => 'generated::8RNhzOaqzOVdOnLq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::YFeTJWHOtrMAOetS' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/travellers/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\TravellerController@delete',
        'controller' => 'App\\Http\\Controllers\\TravellerController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/travellers',
        'where' => 
        array (
        ),
        'as' => 'generated::YFeTJWHOtrMAOetS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZK5rAQtHJGK8cChM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/vacations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\VacationController@index',
        'controller' => 'App\\Http\\Controllers\\VacationController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/vacations',
        'where' => 
        array (
        ),
        'as' => 'generated::ZK5rAQtHJGK8cChM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZAqr0L4lQOtY9D9B' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/vacations/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\VacationController@view',
        'controller' => 'App\\Http\\Controllers\\VacationController@view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/vacations',
        'where' => 
        array (
        ),
        'as' => 'generated::ZAqr0L4lQOtY9D9B',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3nRNdw380wxjDgJy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/vacations/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\VacationController@add',
        'controller' => 'App\\Http\\Controllers\\VacationController@add',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/vacations',
        'where' => 
        array (
        ),
        'as' => 'generated::3nRNdw380wxjDgJy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::7NMfyDftDvIgGuzD' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/vacations/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\VacationController@delete',
        'controller' => 'App\\Http\\Controllers\\VacationController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/vacations',
        'where' => 
        array (
        ),
        'as' => 'generated::7NMfyDftDvIgGuzD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xR6eng0yqnQsfu2U' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/visa_types',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\VisaTypeController@index',
        'controller' => 'App\\Http\\Controllers\\VisaTypeController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/visa_types',
        'where' => 
        array (
        ),
        'as' => 'generated::xR6eng0yqnQsfu2U',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ceWVIjhAOeLB9tmo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/visa_types/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\VisaTypeController@view',
        'controller' => 'App\\Http\\Controllers\\VisaTypeController@view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/visa_types',
        'where' => 
        array (
        ),
        'as' => 'generated::ceWVIjhAOeLB9tmo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SfecdmVlAVQcG7lk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/visa_types/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\VisaTypeController@add',
        'controller' => 'App\\Http\\Controllers\\VisaTypeController@add',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/visa_types',
        'where' => 
        array (
        ),
        'as' => 'generated::SfecdmVlAVQcG7lk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::27F1Sez5HXQkXrv2' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/visa_types/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\VisaTypeController@delete',
        'controller' => 'App\\Http\\Controllers\\VisaTypeController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/visa_types',
        'where' => 
        array (
        ),
        'as' => 'generated::27F1Sez5HXQkXrv2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Q6jHrBeJRAPysGwR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/addons',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AddonController@index',
        'controller' => 'App\\Http\\Controllers\\AddonController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/addons',
        'where' => 
        array (
        ),
        'as' => 'generated::Q6jHrBeJRAPysGwR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xeOp7LMA4vwo2a5O' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/addons/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AddonController@view',
        'controller' => 'App\\Http\\Controllers\\AddonController@view',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/addons',
        'where' => 
        array (
        ),
        'as' => 'generated::xeOp7LMA4vwo2a5O',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6BME6369S6lIhnuK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/addons/viewByVacation/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AddonController@viewByVacation',
        'controller' => 'App\\Http\\Controllers\\AddonController@viewByVacation',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/addons',
        'where' => 
        array (
        ),
        'as' => 'generated::6BME6369S6lIhnuK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ahBrC3LXHcS1uyhh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/addons/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\AddonController@add',
        'controller' => 'App\\Http\\Controllers\\AddonController@add',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/addons',
        'where' => 
        array (
        ),
        'as' => 'generated::ahBrC3LXHcS1uyhh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::UnRZZWMWQnmIo7tF' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/addons/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\AddonController@delete',
        'controller' => 'App\\Http\\Controllers\\AddonController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/addons',
        'where' => 
        array (
        ),
        'as' => 'generated::UnRZZWMWQnmIo7tF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bRbtbhsBE5Fwe7KM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":256:{@+ThIGe+kJmNkwi5N0yEfBoxTiOFL+adwwqHrqHQwHNQ=.a:5:{s:3:"use";a:0:{}s:8:"function";s:44:"function () {
    return \\view(\'welcome\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000157f5fd000000007e404d16";}}',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::bRbtbhsBE5Fwe7KM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'forgot_password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'auth.reset_password',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
